---
name: mytelescope-ai-visibility
description: >
  Use when a user wants to get cited by AI, improve AI visibility, or understand
  how AI systems discover and recommend their brand. Triggers: "AI SEO", "AEO",
  "GEO", "LLMO", "optimize for ChatGPT/Perplexity", "AI citations", "what does
  ChatGPT say about us", "show up in AI answers". Also trigger proactively when
  planning content strategy, SEO, or GTM — AI visibility is now a required layer.
---

# MyTelescope AI Visibility Skill

## 🚫 ABSOLUTE RULES — read before anything else

**Web search:** Every AI citation check runs on `MyTelescope:ai_search`. Claude's
native web search is BANNED for this skill. No fallback. No firing both.

**No tool narration:** Never say "let me get location details", "thinking about...",
or "I'll run this in parallel." Just do the work or ask the questions.

**No skipping phases.** Each phase has a hard stop. Do not proceed until it is done.

---

## PHASE 0 — Scoping gate (FIRST TURN ONLY, no tool calls)

Ask all of these in ONE message, then wait:

1. Exact brand name as it should appear in the audit
2. Website URL (never guess — ask)
3. Target market (pre-fill: "Defaulting to [user location] — change if needed")
4. Single-Minded Idea: what does the brand want to be known for?
5. Competitor set (optional but recommended)

**Do not call any tool until the user replies.**

Escape clause: if user says "skip / just go / quick check" — proceed but mark the
deliverable: *"Running without scoping — findings are observational."*

---

## PHASE 1 — Demand intelligence

**HARD STOP: Complete all steps. Do not build any dashboard or visualization until
Phase 2 is also complete.**

1. `tool_search("demand signals location")` — load MyTelescope tools
2. `get_location_details(location)` — never hardcode a location ID
3. `search_signals(keywords=[brand, category, competitors], location_id)` — pull signals
4. `get_demand_volume(keyword_hashes)` — pull volumes for confirmed signals

Before moving on, answer these four questions from real data:
- What is branded demand volume and trend?
- Is the category Growing, Contracting, or Flat?
- What exact language does the audience use?
- What do competitors own?

---

## PHASE 2 — AI visibility audit

**HARD STOP: Do not present findings, build charts, or save a dashboard until both
steps below are complete. Findings not sourced to a tool call are not findings.**

### Step 1 — Visit the brand's site

```
web_fetch(url="https://[brand].com")
web_fetch(url="https://[brand].com/robots.txt")
web_fetch(url="https://[brand].com/llms.txt")
web_fetch(url="https://[brand].com/pricing")
```

Extract: what the product does, who it's for, what content exists, what's missing.
If a page returns 404, record it as missing. Never guess at contents.

### Step 2 — Run AI Search

Use `MyTelescope:ai_search` with `few_shot_examples`. This queries Perplexity,
OpenAI, Grok, and Gemini in parallel. ONE call covers all four providers.

```
ai_search(
    query="[brand name or category]",
    few_shot_examples=[
        "[brand] what is it",
        "[brand] pricing plans features",
        "best [product category] tools",
        "[brand] vs [top competitor]",
        "[brand] cited mentioned review",
    ]
)
```

Rules for few_shot_examples:
- 3-5 examples covering different intents: definition, commercial findability,
  category, head-to-head, citation layer
- Don't submit five phrasings of the same intent
- Substitute real brand and category names

For a category audit (no single hero brand), use the category as the seed and
persona-based queries as examples:
```
ai_search(
    query="[category]",
    few_shot_examples=[
        "best [category] for [persona A]",
        "best [category] for [persona B]",
        "[brand A] vs [brand B]",
        "safest / most trusted [category]",
        "is [brand] [key attribute]",
    ]
)
```

### What to record from ai_search results

Look across all four provider responses and note:
- Which brands are cited? In how many of the 4 providers?
- What do they say the brand/product does? Accurate, incomplete, or wrong?
- Is pricing findable?
- Are competitors cited where the brand is not?
- Any hallucinations? (flag if repeated across multiple providers)
- Source type: own site vs third-party (brands are 6.5x more likely to be cited
  via third-party sources)

**Always attribute findings to the tool that produced them.** Never present a
finding without stating whether it came from `web_fetch`, `ai_search`, or both.

### AI citation scoring

| Score | Meaning |
|---|---|
| Strong | Cited positively by 3-4 providers in discovery queries |
| Present | Cited by 1-2 providers, or in comparison but not discovery |
| Partial | Cited only in brand-specific queries, not top-of-funnel |
| Not cited | Zero citations across all queries |
| Negative | Cited but primary source is negative review content |

### Content extractability checklist (from web_fetch only)

| Check | Pass / Fail / Unknown |
|---|---|
| Homepage readable without JS? | |
| Clear product definition in first paragraph? | |
| Answer blocks (FAQs, how-tos, comparisons)? | |
| Statistics with cited sources? | |
| AI bots allowed in robots.txt? | |
| /llms.txt exists? | |
| /pricing.md or open pricing page exists? | |

Mark Unknown if page could not be fetched. Never mark Pass/Fail on a page not read.

---

## PHASE 3 — Action plan

Build a prioritized action plan across three pillars. Ground every recommendation
in a specific Phase 1 or Phase 2 finding.

### Pillar 1: Structure — make content extractable

- Lead every section with a direct answer (40-60 words optimal for AI extraction)
- H2/H3 headings must match how people phrase queries — use Phase 1 signal language,
  not internal brand language
- Add FAQ blocks, comparison tables, step-by-step blocks
- Tables beat prose for comparisons; numbered lists beat paragraphs for process

### Pillar 2: Authority — make content citable

Priority methods by visibility lift (Princeton GEO research, KDD 2024):

| Method | Lift |
|---|---|
| Cite sources | +40% |
| Statistics with dated sources | +37% |
| Expert quotes (named, with title) | +30% |
| Authoritative tone | +25% |
| Fluency improvement | +15-30% |
| Keyword stuffing | -10% |

Best combination: fluency + statistics = maximum boost.

### Pillar 3: Presence — be where AI looks

Sources AI cites most:
- Wikipedia (7.8% of ChatGPT citations)
- Reddit (1.8%)
- Industry publications and guest posts
- Review sites (G2, Capterra, TrustRadius for B2B)
- YouTube

Content types cited most: comparison articles (~33%), definitive guides (~15%),
original research (~12%), best-of lists (~10%).

### Action plan format

For each recommendation:
- Priority: High / Medium / Low
- Finding it addresses (cite Phase and specific gap)
- Specific action (not "improve content" — "add a 50-word FAQ block answering
  '[exact query from Phase 1]' to the [page] page")
- Owner: content / dev / PR / comms

---

## PHASE 4 — Save and monitor

After the audit is complete, offer:

1. **Save as MyTelescope dashboard** — use `create_signal_collection` with trackers
   for brand, category, and key competitor signals. Follow dashboard-creation skill
   for the mandatory visualize-first flow.
2. **Set up trend alerts** — `create_trend_alert` for meaningful demand shifts
3. **AI visibility monitoring options:**
   - Otterly AI, Peec AI, ZipTie, LLMrefs (tool coverage varies — check current
     availability with user)
   - DIY: pick top 20 queries from Phase 1, run monthly through ChatGPT/Perplexity/
     Google, log who gets cited and which page

---

## Key tools

| Tool | When |
|---|---|
| `tool_search` | Required before any MyTelescope tool call |
| `get_location_details` | Required before any signal pull |
| `search_signals` | Phase 1 — find demand signals |
| `get_demand_volume` | Phase 1 — pull volume time-series |
| `web_fetch` | Phase 2 Step 1 — read the brand site |
| `MyTelescope:ai_search` | Phase 2 Step 2 — AI citation audit (BANNED: native search) |
| `create_signal_collection` | Phase 4 — save dashboard |
| `generate_platform_link` | Phase 4 — get shareable link (never construct URLs manually) |

---

## Common failures (learned in production)

- Skipping Phase 2 and building a dashboard from Phase 1 data only — the demand
  data is not AI visibility data. They are different things.
- Presenting AI visibility findings without running `ai_search` — inferred findings
  are not findings.
- Using Claude's native web search instead of `MyTelescope:ai_search` — banned.
- Narrating tool flow ("let me now run...") instead of just running it.
- `few_shot_examples` with five paraphrases of the same query — use different intents.
- Marking content checks Pass/Fail without having fetched the page.
