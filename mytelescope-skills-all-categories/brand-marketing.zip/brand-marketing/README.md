# brand-marketing skills

## How to install

1. Unzip this folder.
2. In Claude, go to Settings → Capabilities → Customize.
3. Upload each .md file in this folder.
4. Make sure you have the MyTelescope MCP connector installed (Settings → Connectors → Custom connectors).

## Folder structure

- SKILL.md — entry point (orchestrator, cross-references the others)
- mytelescope-core-SKILL.md — system rules, brand voice, MCP workflow
- The category-specific skills below

## Category skills
- strategic-recipe-brief-SKILL.md
- client-brand-report-SKILL.md
- mytelescope-copywriting-SKILL.md
- client-category-portfolio-SKILL.md
- mytelescope-ai-visibility-SKILL.md
