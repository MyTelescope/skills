# ai-visibility skills

## How to install

1. Unzip this folder.
2. In Claude, go to Settings → Capabilities → Customize.
3. Upload each .md file in this folder.
4. Make sure you have the MyTelescope MCP connector installed (Settings → Connectors → Custom connectors).

## What's inside

**Foundation (always included)**
- mytelescope-core-SKILL.md
- mytelescope-orchestrator-SKILL.md

**Category skills**
- mytelescope-ai-visibility-SKILL.md
- mytelescope-content-strategy-SKILL.md
