# product-marketing skills

## How to install

1. Unzip this folder.
2. In Claude, go to Settings → Capabilities → Customize.
3. Upload each .md file in this folder.
4. Make sure you have the MyTelescope MCP connector installed (Settings → Connectors → Custom connectors).

## Folder structure

- SKILL.md — entry point (orchestrator, cross-references the others)
- mytelescope-core-SKILL.md — system rules, brand voice, MCP workflow
- The category-specific skills below

## Category skills
- mytelescope-product-thinking-SKILL.md
- mytelescope-pricing-distribution-SKILL.md
- client-category-portfolio-SKILL.md
